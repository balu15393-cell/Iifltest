@echo off
setlocal
if not defined ANDROID_HOME (
  echo ANDROID_HOME is not set. Install Android Studio and Android SDK first.
  exit /b 1
)
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle command not found. Open this project in Android Studio or install Gradle 8.7+.
  exit /b 1
)
gradle :app:assembleDebug --no-daemon
if errorlevel 1 exit /b 1
echo.
echo APK created at:
echo %~dp0app\build\outputs\apk\debug\app-debug.apk
