package com.bala.multyfiiifl;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity {
    public static final String PREFS = "auto_trader";
    public static final String KEY_WEBHOOK = "webhook";
    public static final String KEY_SECRET = "secret";
    public static final String KEY_QTY = "qty";
    public static final String KEY_ENABLED = "enabled";
    public static final String KEY_LIVE = "live";
    public static final String KEY_REVIEW = "review";

    private EditText webhook;
    private EditText secret;
    private EditText quantity;
    private Switch enabled;
    private Switch live;
    private Switch review;
    private TextView accessStatus;
    private TextView eventStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(18));

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);

        TextView title = text("Multyfi → IIFL Auto Trader", 24, true);
        root.addView(title);
        root.addView(text("Equity intraday automation • Default BUY quantity: 100", 14, false));
        root.addView(space(12));

        accessStatus = text("Notification access: checking…", 15, true);
        root.addView(accessStatus);

        Button accessButton = new Button(this);
        accessButton.setText("Enable Multyfi Notification Access");
        accessButton.setOnClickListener(v -> {
            try {
                startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            }
        });
        root.addView(accessButton);

        root.addView(space(10));
        enabled = new Switch(this);
        enabled.setText("Automation enabled");
        root.addView(enabled);

        review = new Switch(this);
        review.setText("REVIEW MODE: open IIFL app for manual confirmation");
        root.addView(review);

        live = new Switch(this);
        live.setText("LIVE API execution (do not enable for review testing)");
        root.addView(live);

        root.addView(space(8));
        root.addView(label("Execution server HTTPS URL"));
        webhook = edit("https://YOUR-SERVER.example/execute", false);
        root.addView(webhook);

        root.addView(label("Shared secret"));
        secret = edit("", false);
        secret.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        root.addView(secret);

        root.addView(label("Default BUY quantity"));
        quantity = edit("100", true);
        root.addView(quantity);

        Button save = new Button(this);
        save.setText("Save settings");
        save.setOnClickListener(v -> saveSettings());
        root.addView(save);

        Button testBuy = new Button(this);
        testBuy.setText("TEST BUY → Open IIFL");
        testBuy.setOnClickListener(v -> { saveSettings(); MultyfiNotificationService.testReview(this, "BUY", "TEST", 100); });
        root.addView(testBuy);

        Button testExit = new Button(this);
        testExit.setText("TEST EXIT → Open IIFL");
        testExit.setOnClickListener(v -> { saveSettings(); MultyfiNotificationService.testReview(this, "EXIT", "TEST", 100); });
        root.addView(testExit);

        Button testServer = new Button(this);
        testServer.setText("TEST SERVER (no broker order)");
        testServer.setOnClickListener(v -> { saveSettings(); MultyfiNotificationService.sendTest(this); });
        root.addView(testServer);

        root.addView(space(12));
        TextView rules = text(
                "Safety rules:\n" +
                "• Only Multyfi package com.multyfi.invest is accepted.\n" +
                "• BUY signals use 100 shares by default.\n" +
                "• EXIT signals send quantity=0; the server must read the live IIFL position and close only that position.\n" +
                "• Pre-alert/15-minute messages are ignored.\n" +
                "• SELL/short signals are ignored in this version.\n" +
                "• Duplicate notifications are suppressed.", 14, false);
        root.addView(rules);

        eventStatus = text("Last event: none", 14, false);
        root.addView(space(10));
        root.addView(eventStatus);

        loadSettings();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateAccessStatus();
    }

    private void updateAccessStatus() {
        boolean enabledAccess = isNotificationAccessEnabled(this);
        if (accessStatus != null) {
            accessStatus.setText(enabledAccess ?
                    "Notification access: ENABLED" :
                    "Notification access: NOT ENABLED");
        }
    }

    public static boolean isNotificationAccessEnabled(Context context) {
        String enabledListeners = Settings.Secure.getString(
                context.getContentResolver(),
                "enabled_notification_listeners");
        if (enabledListeners == null) return false;
        ComponentName me = new ComponentName(context, MultyfiNotificationService.class);
        for (String component : enabledListeners.split(":")) {
            ComponentName cn = ComponentName.unflattenFromString(component);
            if (me.equals(cn)) return true;
        }
        return false;
    }

    private void loadSettings() {
        android.content.SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        webhook.setText(p.getString(KEY_WEBHOOK, "https://YOUR-SERVER.example/execute"));
        secret.setText(p.getString(KEY_SECRET, ""));
        quantity.setText(String.valueOf(p.getInt(KEY_QTY, 100)));
        enabled.setChecked(p.getBoolean(KEY_ENABLED, false));
        review.setChecked(p.getBoolean(KEY_REVIEW, true));
        live.setChecked(p.getBoolean(KEY_LIVE, false));
    }

    private void saveSettings() {
        int qty = 100;
        try { qty = Integer.parseInt(quantity.getText().toString().trim()); } catch (Exception ignored) {}
        if (qty <= 0 || qty > 1000) {
            Toast.makeText(this, "Quantity must be 1–1000", Toast.LENGTH_SHORT).show();
            return;
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString(KEY_WEBHOOK, webhook.getText().toString().trim())
                .putString(KEY_SECRET, secret.getText().toString())
                .putInt(KEY_QTY, qty)
                 .putBoolean(KEY_ENABLED, enabled.isChecked())
                .putBoolean(KEY_REVIEW, review.isChecked())
                .putBoolean(KEY_LIVE, live.isChecked())
                .apply();
        Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show();
    }

    public void showEvent(String message) {
        if (eventStatus != null) eventStatus.setText("Last event: " + message);
    }

    private TextView label(String s) { return text(s, 14, true); }
    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setPadding(0, dp(5), 0, dp(5));
        if (bold) t.setTypeface(null, android.graphics.Typeface.BOLD);
        return t;
    }
    private EditText edit(String s, boolean numeric) {
        EditText e = new EditText(this);
        e.setText(s);
        e.setSingleLine(true);
        e.setTextSize(15);
        if (numeric) e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setPadding(dp(10), dp(6), dp(10), dp(6));
        return e;
    }
    private Space space(int h) { Space s = new Space(this); s.setLayoutParams(new LinearLayout.LayoutParams(1, dp(h))); return s; }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
