package com.bala.multyfiiifl;

import android.app.Notification;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MultyfiNotificationService extends NotificationListenerService {
    private static final String TAG = "MultyfiIIFL";
    private static final String MULTYFI_PACKAGE = "com.multyfi.invest";
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private static final Set<String> STOP_WORDS = new HashSet<>(Arrays.asList(
            "NOW", "ABOVE", "BELOW", "AT", "NEAR", "AROUND", "PRICE", "CMP",
            "ENTRY", "TARGET", "SL", "STOP", "LOSS", "HIT", "BOOK", "PROFIT",
            "SHARES", "SHARE", "QTY", "QUANTITY", "EQUITY", "INTRADAY", "TRADE",
            "TRADING", "CALL", "BUY", "EXIT", "SELL", "LONG", "SHORT", "LTP",
            "RS", "INR", "NSE", "BSE", "LIMIT", "MARKET", "STOCK", "STOCKS",
            "THE", "IS", "OF", "FOR", "ON", "AND", "TO", "WITH"
    ));

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (!MULTYFI_PACKAGE.equals(sbn.getPackageName())) return;

        SharedPreferences prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
        if (!prefs.getBoolean(MainActivity.KEY_ENABLED, false)) return;

        Notification n = sbn.getNotification();
        String title = getExtraString(n, Notification.EXTRA_TITLE);
        String text = getExtraString(n, Notification.EXTRA_TEXT);
        String big = getExtraString(n, Notification.EXTRA_BIG_TEXT);
        String raw = join(title, text, big);
        if (raw.trim().isEmpty()) return;

        String action = detectAction(raw);
        if (action == null) return;

        // Multyfi currently sends pre-release notifications such as "trade in 15 mins".
        // Those are informational and must never trigger an order.
        if (isPreAlert(raw)) return;

        String eventId = sha256(MULTYFI_PACKAGE + "|" + title + "|" + text + "|" + big);
        if (isDuplicate(eventId)) return;

        int qty = prefs.getInt(MainActivity.KEY_QTY, 100);
        if (qty <= 0 || qty > 1000) qty = 100;

        String symbolHint = extractSymbol(raw, action);
        boolean live = prefs.getBoolean(MainActivity.KEY_LIVE, false);
        String webhook = prefs.getString(MainActivity.KEY_WEBHOOK, "").trim();
        String secret = prefs.getString(MainActivity.KEY_SECRET, "");
        boolean review = prefs.getBoolean(MainActivity.KEY_REVIEW, true);

        if (review && !live) {
            openIiflForReview(action, symbolHint, action.equals("BUY") ? qty : 0);
            return;
        }

        if (webhook.isEmpty() || webhook.contains("YOUR-SERVER")) {
            logEvent("Signal detected but execution URL is not configured: " + action + " " + symbolHint);
            return;
        }

        try {
            JSONObject body = new JSONObject();
            body.put("event_id", eventId);
            body.put("source", "multyfi");
            body.put("source_package", MULTYFI_PACKAGE);
            body.put("action", action);
            body.put("segment", "EQUITY_INTRADAY");
            body.put("product", "MIS");
            body.put("quantity", action.equals("BUY") ? qty : 0);
            body.put("symbol_hint", symbolHint == null ? JSONObject.NULL : symbolHint);
            body.put("notification_title", title == null ? "" : title);
            body.put("notification_text", text == null ? "" : text);
            body.put("notification_big_text", big == null ? "" : big);
            body.put("received_at", nowIso());
            body.put("live_requested", live);

            sendWebhook(webhook, secret, body.toString(), action, symbolHint);
        } catch (Exception e) {
            Log.e(TAG, "Signal JSON failed", e);
        }
    }

    public static void sendTest(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
        String webhook = prefs.getString(MainActivity.KEY_WEBHOOK, "").trim();
        String secret = prefs.getString(MainActivity.KEY_SECRET, "");
        if (webhook.isEmpty() || webhook.contains("YOUR-SERVER")) {
            logEvent("Test not sent: configure execution URL first.");
            return;
        }
        EXECUTOR.execute(() -> {
            HttpURLConnection c = null;
            try {
                JSONObject body = new JSONObject();
                body.put("event_id", "TEST-" + System.currentTimeMillis());
                body.put("source", "multyfi");
                body.put("action", "TEST");
                body.put("segment", "EQUITY_INTRADAY");
                body.put("product", "MIS");
                body.put("quantity", 100);
                body.put("symbol_hint", "TEST");
                body.put("notification_text", "TEST — this event must never place an order");
                body.put("received_at", nowIso());
                body.put("live_requested", false);

                c = openConnection(webhook, secret);
                writeJson(c, body.toString());
                int code = c.getResponseCode();
                String response = readResponse(c, code);
                logEvent("TEST response " + code + ": " + trim(response));
            } catch (Exception e) {
                logEvent("TEST failed: " + e.getMessage());
            } finally {
                if (c != null) c.disconnect();
            }
        });
    }

    public static void testReview(Context context, String action, String symbol, int qty) {
        openIiflForReviewStatic(context, action, symbol, qty);
    }

    private void openIiflForReview(String action, String symbol, int qty) {
        openIiflForReviewStatic(this, action, symbol, qty);
    }

    private static void openIiflForReviewStatic(Context context, String action, String symbol, int qty) {
        try {
            android.content.Intent launch = context.getPackageManager().getLaunchIntentForPackage("com.indiainfoline");
            if (launch == null) {
                launch = new android.content.Intent(android.content.Intent.ACTION_VIEW,
                        android.net.Uri.parse("https://markets.iiflcapital.com/"));
            }
            launch.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(launch);
            android.widget.Toast.makeText(context,
                    action + " " + (symbol == null ? "" : symbol) + " / Qty " + (qty == 0 ? "actual position" : qty) + "\nIIFL opened for manual review.",
                    android.widget.Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            logEvent("Could not open IIFL: " + e.getMessage());
        }
    }

    private void sendWebhook(String webhook, String secret, String json, String action, String symbol) {
        EXECUTOR.execute(() -> {
            HttpURLConnection c = null;
            try {
                c = openConnection(webhook, secret);
                writeJson(c, json);
                int code = c.getResponseCode();
                String response = readResponse(c, code);
                logEvent(action + " " + (symbol == null ? "" : symbol) + " → HTTP " + code + ": " + trim(response));
            } catch (Exception e) {
                logEvent(action + " " + (symbol == null ? "" : symbol) + " → FAILED: " + e.getMessage());
            } finally {
                if (c != null) c.disconnect();
            }
        });
    }

    private static HttpURLConnection openConnection(String url, String secret) throws Exception {
        URL u = new URL(url);
        HttpURLConnection c = (HttpURLConnection) u.openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(7000);
        c.setReadTimeout(10000);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        c.setRequestProperty("Accept", "application/json");
        if (secret != null && !secret.isEmpty()) c.setRequestProperty("X-AutoTrader-Secret", secret);
        return c;
    }

    private static void writeJson(HttpURLConnection c, String json) throws Exception {
        byte[] data = json.getBytes(StandardCharsets.UTF_8);
        try (OutputStream os = c.getOutputStream()) { os.write(data); }
    }

    private static String readResponse(HttpURLConnection c, int code) throws Exception {
        InputStream stream = code >= 400 ? c.getErrorStream() : c.getInputStream();
        if (stream == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
        }
        return sb.toString();
    }

    private static String getExtraString(Notification n, String key) {
        if (n == null || n.extras == null) return "";
        CharSequence cs = n.extras.getCharSequence(key);
        return cs == null ? "" : cs.toString();
    }

    private static String join(String... parts) {
        StringBuilder sb = new StringBuilder();
        for (String p : parts) {
            if (p != null && !p.trim().isEmpty()) {
                if (sb.length() > 0) sb.append(" | ");
                sb.append(p.trim());
            }
        }
        return sb.toString();
    }

    private static String detectAction(String raw) {
        String s = raw.toUpperCase(Locale.ROOT);
        if (s.contains("EXIT") || s.contains("BOOK PROFIT") || s.contains("SQUARE OFF") ||
                s.contains("STOP LOSS HIT") || s.contains("STOPLOSS HIT") || s.contains("SL HIT")) {
            return "EXIT";
        }
        if (s.matches("(?s).*\\bBUY\\b.*") && !s.contains("15 MIN") && !s.contains("15 MINS")) {
            return "BUY";
        }
        // This version intentionally does not auto-short on SELL notifications.
        return null;
    }

    private static boolean isPreAlert(String raw) {
        String s = raw.toUpperCase(Locale.ROOT);
        return s.contains("15 MIN") || s.contains("15 MINS") || s.contains("15 MINUTE") ||
                s.contains("COMING SOON") || s.contains("UPCOMING") || s.contains("WILL BE POSTED") ||
                s.contains("PRE-ALERT") || s.contains("PRE ALERT") ||
                (s.contains("NEW TRADE") && !s.contains("BUY"));
    }

    private static String extractSymbol(String raw, String action) {
        String upper = raw.toUpperCase(Locale.ROOT);
        int start = -1;
        String marker = action.equals("BUY") ? "BUY" : "EXIT";
        start = upper.indexOf(marker);
        if (start < 0 && action.equals("EXIT")) start = upper.indexOf("BOOK PROFIT");
        if (start < 0) return null;

        String tail = upper.substring(Math.min(upper.length(), start + marker.length()));
        String[] tokens = tail.replaceAll("[^A-Z0-9&.-]+", " ").trim().split("\\s+");
        for (String token : tokens) {
            if (token.isEmpty()) continue;
            if (STOP_WORDS.contains(token)) continue;
            if (token.matches("\\d+(?:\\.\\d+)?")) continue;
            if (token.length() >= 2 && token.length() <= 20) return token;
        }
        return null;
    }

    private boolean isDuplicate(String eventId) {
        SharedPreferences p = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
        String last = p.getString("last_event_id", "");
        long lastTs = p.getLong("last_event_ts", 0L);
        long now = System.currentTimeMillis();
        if (eventId.equals(last) && now - lastTs < 180_000L) return true;
        p.edit().putString("last_event_id", eventId).putLong("last_event_ts", now).apply();
        return false;
    }

    private static String sha256(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(s.getBytes(StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder();
            for (byte b : bytes) out.append(String.format(Locale.ROOT, "%02x", b));
            return out.toString();
        } catch (Exception e) {
            return String.valueOf(s.hashCode());
        }
    }

    private static String nowIso() {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.ROOT);
        f.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
        return f.format(new Date());
    }

    private static String trim(String s) {
        if (s == null) return "";
        s = s.replace('\n', ' ').replace('\r', ' ');
        return s.length() > 240 ? s.substring(0, 240) : s;
    }

    private static void logEvent(String msg) {
        Log.i(TAG, msg);
        // The service may not have an Activity instance. Logcat remains available
        // for diagnostics; the UI also reads this through future versions.
    }
}
