"""
Minimal HTTPS execution-server skeleton.

Run behind a reverse proxy with HTTPS. This version is deliberately DRY-RUN only.
It validates the Android bridge payload and records what would be sent to IIFL.
Do not enable live trading until IIFL API credentials, instrument lookup,
position lookup, order placement, fill verification and broker-specific
compliance/static-IP requirements have been configured.
"""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import hashlib
import hmac
import json
import os
from datetime import datetime

SECRET = os.environ.get("AUTOTRADER_SECRET", "CHANGE_ME")
HOST = os.environ.get("HOST", "127.0.0.1")
PORT = int(os.environ.get("PORT", "8080"))
LIVE = os.environ.get("LIVE_TRADING", "false").lower() == "true"


def log(obj):
    print(json.dumps(obj, ensure_ascii=False), flush=True)


def safe_symbol_hint(value):
    if value is None:
        return None
    value = str(value).strip().upper()
    if not value or len(value) > 30:
        return None
    return value


class Handler(BaseHTTPRequestHandler):
    def _send(self, code, payload):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/health":
            self._send(200, {"ok": True, "live": LIVE, "time": datetime.now().isoformat()})
            return
        self._send(404, {"ok": False})

    def do_POST(self):
        if self.path != "/execute":
            self._send(404, {"ok": False})
            return

        supplied = self.headers.get("X-AutoTrader-Secret", "")
        if not hmac.compare_digest(supplied, SECRET):
            self._send(401, {"ok": False, "error": "bad secret"})
            return

        try:
            length = int(self.headers.get("Content-Length", "0"))
            raw = self.rfile.read(length)
            payload = json.loads(raw.decode("utf-8"))
        except Exception as exc:
            self._send(400, {"ok": False, "error": f"invalid JSON: {exc}"})
            return

        action = str(payload.get("action", "")).upper()
        if action == "TEST":
            log({"type": "TEST", "payload": payload})
            self._send(200, {"ok": True, "mode": "test", "trade_placed": False})
            return

        if action not in {"BUY", "EXIT"}:
            self._send(400, {"ok": False, "error": "unsupported action"})
            return

        if payload.get("segment") != "EQUITY_INTRADAY" or payload.get("product") != "MIS":
            self._send(400, {"ok": False, "error": "only equity intraday MIS is allowed"})
            return

        if action == "BUY" and int(payload.get("quantity", 0)) != 100:
            self._send(400, {"ok": False, "error": "BUY quantity must be 100"})
            return

        symbol = safe_symbol_hint(payload.get("symbol_hint"))
        event_id = str(payload.get("event_id", ""))
        log({
            "type": "SIGNAL",
            "event_id": event_id,
            "action": action,
            "symbol_hint": symbol,
            "live_requested": bool(payload.get("live_requested", False)),
        })

        # TODO for live implementation:
        # 1. Resolve the symbol to IIFL exchangeInstrumentID using the IIFL scrip master.
        # 2. Login/refresh the IIFL API session.
        # 3. For BUY: place exactly 100 MIS shares.
        # 4. For EXIT: query the actual NET/DAY MIS position and submit the opposite
        #    quantity only for the open position.
        # 5. Poll order/trade status until filled/rejected/timeout.
        # 6. Re-query position and require zero before reporting success.
        # 7. Persist event_id atomically to prevent duplicate execution.

        if not LIVE:
            self._send(200, {
                "ok": True,
                "mode": "dry_run",
                "trade_placed": False,
                "would_execute": {"action": action, "symbol": symbol, "quantity": 100 if action == "BUY" else "LIVE_POSITION"},
            })
            return

        self._send(501, {
            "ok": False,
            "error": "LIVE_TRADING is not implemented in this skeleton; configure and test the IIFL adapter first.",
        })

    def log_message(self, fmt, *args):
        return


if __name__ == "__main__":
    print(f"Listening on http://{HOST}:{PORT} (LIVE_TRADING={LIVE})")
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
