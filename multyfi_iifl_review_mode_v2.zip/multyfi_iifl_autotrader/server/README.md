# Execution server

The Android APK should call:

`POST https://YOUR-SERVER/execute`

with header:

`X-AutoTrader-Secret: <shared secret>`

The included `server.py` is intentionally **dry-run only**. It does not place real orders.

For live IIFL execution, implement the IIFL adapter on a server that meets the broker/exchange requirements. The adapter must:

1. authenticate/refresh the IIFL API session;
2. resolve the equity symbol to the correct IIFL exchange instrument ID;
3. verify the instrument is permitted for intraday;
4. BUY exactly 100 shares for a BUY signal;
5. for EXIT, query the actual open MIS position and submit the opposite side for only the remaining quantity;
6. verify order/trade status;
7. re-query the position and require zero before reporting success;
8. store processed event IDs atomically to block duplicate execution;
9. never trust a client-supplied exit quantity;
10. keep IIFL credentials on the server, never in the Android APK.
