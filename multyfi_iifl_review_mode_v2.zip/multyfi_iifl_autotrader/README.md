# Multyfi → IIFL Auto Trader (Android bridge)

This project is a build-ready Android notification bridge for the user's requested workflow:

**Multyfi notification → Android NotificationListenerService → HTTPS execution server → IIFL API**

Defaults:
- BUY quantity: **100 shares**
- Product: **MIS / intraday**
- BUY: automatic request for 100 shares
- EXIT: quantity is **0** in the event; the execution server must query the live IIFL position and close only the actual remaining position
- SELL/short signals: ignored in this version
- Multyfi package: `com.multyfi.invest`
- 15-minute/pre-alert messages: ignored
- duplicate alerts: suppressed for 3 minutes

## Important

The APK intentionally does **not** store IIFL API credentials. A phone should not be used as the IIFL execution server if the broker/API setup requires a fixed/whitelisted source IP. The APK sends a signed/secret-header HTTPS request to your execution server; the server performs the IIFL login, position lookup and order placement.

IIFL confirms that its Open APIs provide authorization/login, order, reports and transaction APIs, and that an active IIFL trading account is required to obtain API keys. IIFL currently says API keys are valid for six months.

## First run

1. Install the APK.
2. Open it.
3. Tap **Enable Multyfi Notification Access** and enable the service in Android Settings.
4. Enter your HTTPS execution-server URL and shared secret.
5. Keep **LIVE execution** OFF initially.
6. Use **Send TEST event** and confirm the server receives it.
7. Only after the complete path is tested should LIVE execution be enabled.

## Build

Android Studio can open this folder directly.

Or use the included GitHub Actions workflow. It builds a debug APK and publishes it as an Actions artifact.

The current execution server URL is deliberately a placeholder. No real trade can be placed until a real server is configured.
